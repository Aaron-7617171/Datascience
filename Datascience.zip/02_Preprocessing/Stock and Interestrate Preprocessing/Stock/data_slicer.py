import pandas as pd
import os

# Relativer Pfad zu den Excel-Dateien
script_dir = os.path.dirname(os.path.abspath(__file__))
base_dir = os.path.join(script_dir, "Stock Data Raw")

# Dateinamen
files = {
    "DAX": "DAX.xlsx",
    "MDAX": "MDAX.xlsx", 
    "SDAX": "SDAX.xlsx"
}

# Zeitraum definieren (deutsches Format)
start_date_str = "01.04.2022"
end_date_str = "10.04.2022"

# Umwandlung in datetime
start_date = pd.to_datetime(start_date_str, dayfirst=True)
end_date = pd.to_datetime(end_date_str, dayfirst=True)

# Dictionary zum Speichern der gefilterten Daten
data = {}

# Daten aus jeder Excel-Datei laden und filtern
for key, filename in files.items():
    filepath = os.path.join(base_dir, filename)
    
    # Excel laden (Sheet-Name entspricht dem Format aus deinem Downloader)
    df = pd.read_excel(filepath, sheet_name=f"{key}_EUR", index_col=0)
    
    # Index in datetime umwandeln (falls noch nicht geschehen)
    df.index = pd.to_datetime(df.index, dayfirst=True)
    
    # Filter nach Zeitraum und nur Open/Close Spalten
    df_filtered = df.loc[(df.index >= start_date) & (df.index <= end_date), ["Open", "Close"]]
    
    # Speichern
    data[key] = df_filtered

# Kombiniertes DataFrame erstellen
combined_df = pd.DataFrame(index=data["DAX"].index)

# DATE Spalte als datetime hinzufügen
combined_df['DATE'] = combined_df.index

# Spalten für jeden Index hinzufügen
for key in data:
    combined_df[f'OPEN_{key}'] = data[key]['Open']
    combined_df[f'CLOSE_{key}'] = data[key]['Close']

# Ausgabe der ersten 5 Zeilen
print("Kombiniertes DataFrame:")
print(combined_df.head())

# Datentypen aller Spalten anzeigen
print("\nDatentypen der Spalten:")
print(combined_df.dtypes)
