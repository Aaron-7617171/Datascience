import pandas as pd
import os
import warnings
import numpy as np

warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")

# ============================================
# CONFIGURATION - EDIT HERE
# ============================================
# Input folder and files
input_folder = "Data"
interest_file = "interest_rate_2022_2025.xlsx"
stock_file = "stock_data_combined_onehot.xlsx"

# Output folder and file
output_folder = "Dataset"
output_file = "DS_threedays.xlsx"
# ============================================

# File paths
os.chdir(os.path.dirname(os.path.abspath(__file__)))

# Load interest rate data with Date as index
interest_path = os.path.join(input_folder, interest_file)
df_interest = pd.read_excel(interest_path, index_col=0, parse_dates=True)

# Load stock data with Date as index
stock_path = os.path.join(input_folder, stock_file)
df_stock = pd.read_excel(stock_path, index_col=0, parse_dates=True)

# Convert one-hot encoded columns to float in stock data
onehot_cols = [col for col in df_stock.columns if col.startswith('Index_')]
df_stock[onehot_cols] = df_stock[onehot_cols].astype(float)

# Copy df_stock to df_neu
df_neu = df_stock.copy()

# Find common dates between df_neu and df_interest
common_dates = df_neu.index.intersection(df_interest.index)

# Filter df_neu to keep only rows with dates present in both dataframes
df_neu = df_neu.loc[common_dates]

# Initialize additional columns at specific positions
df_neu.insert(2, 'Close_t+1', np.nan)  # Position 2
df_neu.insert(3, 'Close_t+2', np.nan)  # Position 3
df_neu.insert(4, 'Close_t+3', np.nan)  # Position 4

# Fill Close_t+1, Close_t+2, Close_t+3 values
for idx, row in df_neu.iterrows():
    # Find next rows in df_stock with same Index combination
    same_company = df_stock[(df_stock['Index_DAX'] == row['Index_DAX']) & 
                           (df_stock['Index_MDAX'] == row['Index_MDAX']) & 
                           (df_stock['Index_SDAX'] == row['Index_SDAX']) & 
                           (df_stock.index > idx)]
    
    if len(same_company) >= 1:
        df_neu.loc[idx, 'Close_t+1'] = same_company.iloc[0]['Close']
    if len(same_company) >= 2:
        df_neu.loc[idx, 'Close_t+2'] = same_company.iloc[1]['Close']
    if len(same_company) >= 3:
        df_neu.loc[idx, 'Close_t+3'] = same_company.iloc[2]['Close']

# Add Interest Rate columns to df_neu from df_interest
df_neu['Interest Rate_Old'] = df_interest.loc[common_dates, 'Interest Rate_Old']
df_neu['Interest Rate_Change'] = df_interest.loc[common_dates, 'Interest Rate_Change']

# Save df_neu to Excel
os.makedirs(output_folder, exist_ok=True)
df_neu.to_excel(f"{output_folder}/{output_file}", index=True)

# Display head(-3) of dataframes
print("Interest Rate DataFrame:")
print(df_interest)

print("Interest Rate DataFrame:")
print(df_stock)

print("\ndf_neu (filtered and merged):")
print(df_neu)

print(f"\nInterest Rate DataFrame dimensions: {df_interest.shape[0]} rows × {df_interest.shape[1]} columns")
print(f"df_neu dimensions: {df_neu.shape[0]} rows × {df_neu.shape[1]} columns")
print(f"Common dates found: {len(common_dates)}")

print("\nInterest Rate DataFrame columns:")
for col in df_interest.columns:
    print(f"   • {col}: {df_interest[col].dtype}")

print("\ndf_neu columns:")
for col in df_neu.columns:
    print(f"   • {col}: {df_neu[col].dtype}")

print(f"\n✅ File saved: {output_folder}/{output_file}")
