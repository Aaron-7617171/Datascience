import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.dates import DateFormatter
import matplotlib.dates as mdates
from datetime import datetime
from matplotlib.ticker import FuncFormatter

def normalize_data(df):
    """
    Normalize stock data so that each series starts at 100
    """
    return df.div(df.iloc[0]) * 100

def create_stock_chart(file_path, num_stocks, normalize=True, output_path='stock_chart.png'):
    """
    Create a stock chart from Excel data
    
    Parameters:
    -----------
    file_path : str
        Path to the Excel file containing stock data
    num_stocks : int
        Number of stocks to plot
    normalize : bool
        Whether to normalize the data to start at 100
    output_path : str
        Path where to save the chart image
    """
    # Read the Excel file
    df = pd.read_excel(file_path)
    
    # Convert the first column to datetime
    df[df.columns[0]] = pd.to_datetime(df[df.columns[0]], format='%d.%m.%Y')
    df.set_index(df.columns[0], inplace=True)  # Set the first column as index
    
    # Get stock columns (skip first two columns: date, EZB, FED)
    stock_columns = df.columns[2:]
    
    # Select only the specified number of stocks
    if num_stocks > len(stock_columns):
        print(f"Warnung: Es sind nur {len(stock_columns)} Aktien in der Datei vorhanden.")
        num_stocks = len(stock_columns)
    
    # Get the stock names
    selected_stocks = stock_columns[:num_stocks]
    stock_data = df[selected_stocks]
    
    # Check if values contain currency symbols
    first_value = str(stock_data.iloc[0, 0])
    has_currency = any(char in first_value for char in ['€', '$', '£', '¥'])
    
    # Normalize the data if requested
    if normalize:
        stock_data = normalize_data(stock_data)
        y_label = 'Normalized Value (Starting at 100%)'
    else:
        y_label = 'Value'
        if has_currency:
            y_label += ' (in original currency)'
    
    # Create the plot
    plt.figure(figsize=(12, 6))
    
    # Plot each stock
    for column in stock_data.columns:
        plt.plot(stock_data.index, stock_data[column], label=column, linewidth=2)
    
    # Add vertical lines for EZB and FED rate changes
    # EZB rate changes (black lines)
    ezb_dates = df[df[df.columns[0]] == 3].index
    for date in ezb_dates:
        plt.axvline(x=date, color='black', linestyle='--', alpha=0.5, label='EZB' if date == ezb_dates[0] else "")
    
    # FED rate changes (green lines)
    fed_dates = df[df[df.columns[1]] == 3].index
    for date in fed_dates:
        plt.axvline(x=date, color='green', linestyle='--', alpha=0.5, label='FED' if date == fed_dates[0] else "")
    
    # Customize the plot
    plt.title('Stock Performance', fontsize=14, pad=20)
    
    # Format the x-axis dates in German format
    plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%d.%m.%Y'))
    plt.gca().xaxis.set_major_locator(mdates.MonthLocator(interval=3))
    plt.xticks(rotation=45)
    
    # Format Y-axis based on normalization
    if normalize:
        def percentage_formatter(x, pos):
            return f'{x:.0f}%'
        plt.gca().yaxis.set_major_formatter(FuncFormatter(percentage_formatter))
    else:
        if has_currency:
            def currency_formatter(x, pos):
                return f'{x:,.0f}'
            plt.gca().yaxis.set_major_formatter(FuncFormatter(currency_formatter))
    
    # Add grid and legend
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.legend(loc='best', frameon=True, shadow=True)
    
    # Adjust layout and save
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"Chart has been saved to {output_path}")
    print(f"Folgende Aktien wurden dargestellt: {', '.join(selected_stocks)}")
    

if __name__ == "__main__":
    # Get user input for number of stocks
    while True:
        try:
            num_stocks = int(input("Wie viele Aktien möchten Sie darstellen? "))
            if num_stocks > 0:
                break
            else:
                print("Bitte geben Sie eine positive Zahl ein.")
        except ValueError:
            print("Bitte geben Sie eine gültige Zahl ein.")
    
    # Get user input for normalization
    while True:
        normalize_input = input("Möchten Sie die Daten normalisieren? (y/n): ").lower()
        if normalize_input in ['y', 'n']:
            normalize = normalize_input == 'y'
            break
        else:
            print("Bitte geben Sie 'y' für Ja oder 'n' für Nein ein.")
    
    # Example usage
    excel_file = "GDAXI PowerBi_2.xlsx"  # Replace with your Excel file path
    create_stock_chart(excel_file, num_stocks, normalize) 
    