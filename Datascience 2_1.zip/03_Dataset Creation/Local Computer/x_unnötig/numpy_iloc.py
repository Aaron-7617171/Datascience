import pandas as pd
import os
import warnings
import numpy as np

warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")

# ============================================
# CONFIGURATION - EDIT HERE
# ============================================
# Input folder and files
input_folder = "Data"
interest_file = "interest_rate_2022_2025.xlsx"
stock_file = "stock_data_combined_onehot.xlsx"

# Output folder and file
output_folder = "Dataset"
output_file = "DS_threedays.xlsx"
# ============================================

# File paths
os.chdir(os.path.dirname(os.path.abspath(__file__)))

# Load interest rate data with Date as index
interest_path = os.path.join(input_folder, interest_file)
df_interest = pd.read_excel(interest_path, index_col=0, parse_dates=True)

# Load stock data with Date as index
stock_path = os.path.join(input_folder, stock_file)
df_stock = pd.read_excel(stock_path, index_col=0, parse_dates=True)

# Convert one-hot encoded columns to float in stock data
onehot_cols = [col for col in df_stock.columns if col.startswith('Index_')]
df_stock[onehot_cols] = df_stock[onehot_cols].astype(float)

# Copy df_stock to df_neu
df_neu = df_stock.copy()






# Find common dates between df_neu and df_interest
common_dates = df_neu.index.intersection(df_interest.index)

# Filter df_neu to keep only rows with dates present in both dataframes
df_neu = df_neu.loc[common_dates]



# Initialize additional columns at specific positions
df_neu.insert(2, 'Close_t+1', np.nan)  # Position 2
df_neu.insert(3, 'Close_t+2', np.nan)  # Position 3
df_neu.insert(4, 'Close_t+3', np.nan)  # Position 4


# Add Interest Rate columns to df_neu from df_interest
df_neu['Interest Rate_Old'] = df_interest.loc[common_dates, 'Interest Rate_Old']
df_neu['Interest Rate_Change'] = df_interest.loc[common_dates, 'Interest Rate_Change']

# Save df_neu to Excel
os.makedirs(output_folder, exist_ok=True)
df_neu.to_excel(f"{output_folder}/{output_file}", index=True)

# Display head(-3) of dataframes
print("Interest Rate DataFrame:")
print(df_interest)

print("\ndf_neu (filtered and merged):")
#print(df_neu.head(-3))
print(df_neu)

print(f"\nInterest Rate DataFrame dimensions: {df_interest.shape[0]} rows × {df_interest.shape[1]} columns")
print(f"df_neu dimensions: {df_neu.shape[0]} rows × {df_neu.shape[1]} columns")
print(f"Common dates found: {len(common_dates)}")

print("\nInterest Rate DataFrame columns:")
for col in df_interest.columns:
    print(f"   • {col}: {df_interest[col].dtype}")

print("\ndf_neu columns:")
for col in df_neu.columns:
    print(f"   • {col}: {df_neu[col].dtype}")

print(f"\n✅ File saved: {output_folder}/{output_file}")



"""
# Convert index to datetime if it's not already


# Then search again
search_date = pd.to_datetime('2022-06-09')
result = df_stock[(df_stock.index == search_date) & (df_stock['Index_MDAX'] == 1.0)]
print(result)

next_row = df_stock[(df_stock.index > search_date) & (df_stock['Index_MDAX'] == 1.0)]

search_date = pd.to_datetime('2022-06-10')
result = df_stock[(df_stock.index == search_date) & (df_stock['Index_MDAX'] == 1.0)]
print(result)

search_date = pd.to_datetime('2022-06-13')
result = df_stock[(df_stock.index == search_date) & (df_stock['Index_MDAX'] == 1.0)]
print(result)
"""



print("AAAAAAAAAAa")

df_stock.index = pd.to_datetime(df_stock.index, format='%d.%m.%Y')

print(common_dates)
print(common_dates[0])

# Variable for index column
index_column = 'Index_MDAX'  # Change this as needed

# Simplest version
# Find iloc position - working version
search_date_str = common_dates[0]  # '09.06.2022'
search_date = pd.to_datetime(search_date_str, dayfirst=True)
mask = (df_stock.index == search_date) & (df_stock[index_column] == 1.0)
iloc_position = np.where(mask)[0][0]
print(f"iloc position: {iloc_position}")
# Access specific columns from row
close_value = df_stock.iloc[iloc_position]['Close']
print(f"Close value: {close_value}")
close_value_next = df_stock.iloc[iloc_position + 1]['Close']
print(f"Close_t+1: {close_value_next}")
close_value_next_next = df_stock.iloc[iloc_position + 2]['Close']
print(f"Close_t+2: {close_value_next_next}")
rows = df_stock.iloc[iloc_position:iloc_position + 3]
print(rows)
print("AAAAA")

"""
# Finde die Spalte mit Wert 1.0 in der ersten Zeile
first_row = df_neu.iloc[0]
index_columns = ['Index_DAX', 'Index_MDAX', 'Index_SDAX']
column_with_one = [col for col in index_columns if first_row[col] == 1.0][0]
print(f"Spalte mit 1.0: {column_with_one}")
"""

# Durch die ersten 5 Zeilen iterieren
n = len(df_neu)
index_columns = ['Index_DAX', 'Index_MDAX', 'Index_SDAX']

for i in range(n):
    row = df_neu.iloc[i]
    date = df_neu.index[i]
    
    # Finde Spalte mit 1.0
    column_with_one = [col for col in index_columns if row[col] == 1.0][0]
    
    print(f"Zeile {i}: Date: {date}, Spalte mit 1.0: {column_with_one}")


print("AAAAAAAAAAAAAAAAA")
# Durch alle Zeilen von df_neu iterieren und Close_t+1, Close_t+2, Close_t+3 füllen
df_stock.index = pd.to_datetime(df_stock.index, format='%d.%m.%Y')

n = len(df_neu)
index_columns = ['Index_DAX', 'Index_MDAX', 'Index_SDAX']

for i in range(n):
    row = df_neu.iloc[i]
    date = df_neu.index[i]
    
    # Finde Spalte mit 1.0
    column_with_one = [col for col in index_columns if row[col] == 1.0][0]
    
    # Suche entsprechende Position in df_stock
    search_date = pd.to_datetime(date, dayfirst=True)
    mask = (df_stock.index == search_date) & (df_stock[column_with_one] == 1.0)
    
    if mask.any():
        iloc_position = np.where(mask)[0][0]
        
        # Fülle Close_t+1, Close_t+2, Close_t+3 Werte
        try:
            df_neu.iloc[i, df_neu.columns.get_loc('Close_t+1')] = df_stock.iloc[iloc_position + 1]['Close']
            df_neu.iloc[i, df_neu.columns.get_loc('Close_t+2')] = df_stock.iloc[iloc_position + 2]['Close']
            df_neu.iloc[i, df_neu.columns.get_loc('Close_t+3')] = df_stock.iloc[iloc_position + 3]['Close']
        except IndexError:
            pass  # Skip if not enough future data
        
        print(f"Zeile {i}: Date: {date}, Index: {column_with_one}, Position: {iloc_position}")



print(df_neu)